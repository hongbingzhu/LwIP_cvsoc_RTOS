#ifndef __NETBIOS_H__
#define __NETBIOS_H__

void netbios_init(void);

#endif /* __NETBIOS_H__ */
