#ifndef __UNISTD_H__
#define __UNISTD_H__

/* include io.h for read() and write() */
#include <io.h>

#endif
